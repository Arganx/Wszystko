<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\users1;

class MyController extends Controller
{
    /**
     * @Route("/my", name="my_list")
     */
    public function listAction(Request $request)
    {
        return $this->render('my/my.html.twig');
    }

    /**
     * @Route("/second", name="my_second")
     */
    public function secondAction(Request $request)
    {

        $user = $this->getDoctrine()
            ->getRepository('AppBundle:users1')
            ->findAll();
        return $this->render('my/second.html.twig',array('theUser'=>$user));
    }
}
