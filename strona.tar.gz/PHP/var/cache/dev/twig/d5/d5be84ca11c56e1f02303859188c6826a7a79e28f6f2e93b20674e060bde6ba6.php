<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_4e3271903e33ece75271e854a17246dc43a169ac90a69a863843468c5ada6dd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_08c8e8384ab09e7a6d5953afdbc83bc8bfce0b6f47119f0876384f87ac819e68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08c8e8384ab09e7a6d5953afdbc83bc8bfce0b6f47119f0876384f87ac819e68->enter($__internal_08c8e8384ab09e7a6d5953afdbc83bc8bfce0b6f47119f0876384f87ac819e68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_05c9153d2965a77ccbe90dd8c77111135f22e2806e450b67b8ca8d3ccf3b8a55 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05c9153d2965a77ccbe90dd8c77111135f22e2806e450b67b8ca8d3ccf3b8a55->enter($__internal_05c9153d2965a77ccbe90dd8c77111135f22e2806e450b67b8ca8d3ccf3b8a55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_08c8e8384ab09e7a6d5953afdbc83bc8bfce0b6f47119f0876384f87ac819e68->leave($__internal_08c8e8384ab09e7a6d5953afdbc83bc8bfce0b6f47119f0876384f87ac819e68_prof);

        
        $__internal_05c9153d2965a77ccbe90dd8c77111135f22e2806e450b67b8ca8d3ccf3b8a55->leave($__internal_05c9153d2965a77ccbe90dd8c77111135f22e2806e450b67b8ca8d3ccf3b8a55_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_5af56287a7298f9a07a54c82caebcafe1f91c1f404f1b5244b1ce4e379438ab3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5af56287a7298f9a07a54c82caebcafe1f91c1f404f1b5244b1ce4e379438ab3->enter($__internal_5af56287a7298f9a07a54c82caebcafe1f91c1f404f1b5244b1ce4e379438ab3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_71c2b6603173dd4b3ae589bfbbcaefb37e0f03150426ee5d63493d447bfe9825 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_71c2b6603173dd4b3ae589bfbbcaefb37e0f03150426ee5d63493d447bfe9825->enter($__internal_71c2b6603173dd4b3ae589bfbbcaefb37e0f03150426ee5d63493d447bfe9825_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_71c2b6603173dd4b3ae589bfbbcaefb37e0f03150426ee5d63493d447bfe9825->leave($__internal_71c2b6603173dd4b3ae589bfbbcaefb37e0f03150426ee5d63493d447bfe9825_prof);

        
        $__internal_5af56287a7298f9a07a54c82caebcafe1f91c1f404f1b5244b1ce4e379438ab3->leave($__internal_5af56287a7298f9a07a54c82caebcafe1f91c1f404f1b5244b1ce4e379438ab3_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b6b6bdc536439267ef7e62662a8422f8d1fedfccbfb3dc8c3bda2a0722a45f0d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b6b6bdc536439267ef7e62662a8422f8d1fedfccbfb3dc8c3bda2a0722a45f0d->enter($__internal_b6b6bdc536439267ef7e62662a8422f8d1fedfccbfb3dc8c3bda2a0722a45f0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_41b6f2041d17cc01ceb1012cb3e946345af01e2c01e01e57a4e37f0b6d1d5c9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41b6f2041d17cc01ceb1012cb3e946345af01e2c01e01e57a4e37f0b6d1d5c9d->enter($__internal_41b6f2041d17cc01ceb1012cb3e946345af01e2c01e01e57a4e37f0b6d1d5c9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_41b6f2041d17cc01ceb1012cb3e946345af01e2c01e01e57a4e37f0b6d1d5c9d->leave($__internal_41b6f2041d17cc01ceb1012cb3e946345af01e2c01e01e57a4e37f0b6d1d5c9d_prof);

        
        $__internal_b6b6bdc536439267ef7e62662a8422f8d1fedfccbfb3dc8c3bda2a0722a45f0d->leave($__internal_b6b6bdc536439267ef7e62662a8422f8d1fedfccbfb3dc8c3bda2a0722a45f0d_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c4c46253b945d81ccf4e778b355902bdf27d66dbca60a1caaaa70f432cbd4960 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4c46253b945d81ccf4e778b355902bdf27d66dbca60a1caaaa70f432cbd4960->enter($__internal_c4c46253b945d81ccf4e778b355902bdf27d66dbca60a1caaaa70f432cbd4960_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c161744f1dd12df9dba342a42e47a96404fd5885e5adf0e886fd80f483224c0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c161744f1dd12df9dba342a42e47a96404fd5885e5adf0e886fd80f483224c0d->enter($__internal_c161744f1dd12df9dba342a42e47a96404fd5885e5adf0e886fd80f483224c0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_c161744f1dd12df9dba342a42e47a96404fd5885e5adf0e886fd80f483224c0d->leave($__internal_c161744f1dd12df9dba342a42e47a96404fd5885e5adf0e886fd80f483224c0d_prof);

        
        $__internal_c4c46253b945d81ccf4e778b355902bdf27d66dbca60a1caaaa70f432cbd4960->leave($__internal_c4c46253b945d81ccf4e778b355902bdf27d66dbca60a1caaaa70f432cbd4960_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
