<?php

/* base.html.twig */
class __TwigTemplate_ef6a598e82a5011af52d5b328f0cd2f8830bea5f4c88506ad9e23671aec9697a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c163f9cdfe0086c469ce24b2256c50d1c67563c3cc370fc935b620144a67870 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c163f9cdfe0086c469ce24b2256c50d1c67563c3cc370fc935b620144a67870->enter($__internal_5c163f9cdfe0086c469ce24b2256c50d1c67563c3cc370fc935b620144a67870_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_12bbdfc80abb2b450339795ff53d8290b16052453ca6f682f414f3e2e21be2fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12bbdfc80abb2b450339795ff53d8290b16052453ca6f682f414f3e2e21be2fc->enter($__internal_12bbdfc80abb2b450339795ff53d8290b16052453ca6f682f414f3e2e21be2fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"description\" content=\"Testing site\">
    <meta name=\"author\" content=\"Mikołaj\">
    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/menu_style.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
    ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "
    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

</head>

<body>
<h1 id=\"Main_text\">Hotel</h1>

<nav>
        <ul class=\"ul_menu\">
            <li class=\"li_menu\">
                <a href=\"/\">Domowa</a>
                <a href=\"/my\">Aktualnosci</a>
                <a href=\"/second\">Kontakt</a>
            </li>

            <li class=\"login\">
                <input class=\"login\" type=\"text\" placeholder=\"login\" aria-label=\"log\">
                <input class=\"login\" type=\"password\" placeholder=\"password\" aria-label=\"pass\">
                <button class=\"search_button\" type=\"submit\">Login</button>
            </li>
        </ul>
</nav>

<div class=\"container\">

    <div class=\"row\">
        <div class=\"call-md-12\">
            ";
        // line 39
        $this->displayBlock('body', $context, $blocks);
        // line 40
        echo "        </div>
    </div>

</div><!-- /.container -->
";
        // line 44
        $this->displayBlock('javascripts', $context, $blocks);
        // line 74
        echo "</body>
</html>
";
        
        $__internal_5c163f9cdfe0086c469ce24b2256c50d1c67563c3cc370fc935b620144a67870->leave($__internal_5c163f9cdfe0086c469ce24b2256c50d1c67563c3cc370fc935b620144a67870_prof);

        
        $__internal_12bbdfc80abb2b450339795ff53d8290b16052453ca6f682f414f3e2e21be2fc->leave($__internal_12bbdfc80abb2b450339795ff53d8290b16052453ca6f682f414f3e2e21be2fc_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_50d1a457991143a00cf242dedf0acb00a673cc96a92812ae002f5df3649b9fba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50d1a457991143a00cf242dedf0acb00a673cc96a92812ae002f5df3649b9fba->enter($__internal_50d1a457991143a00cf242dedf0acb00a673cc96a92812ae002f5df3649b9fba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_453ec6326e4d5715043486d4f0f12b882793813f70c26133f22fb9c40d3b4cca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_453ec6326e4d5715043486d4f0f12b882793813f70c26133f22fb9c40d3b4cca->enter($__internal_453ec6326e4d5715043486d4f0f12b882793813f70c26133f22fb9c40d3b4cca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "
    ";
        
        $__internal_453ec6326e4d5715043486d4f0f12b882793813f70c26133f22fb9c40d3b4cca->leave($__internal_453ec6326e4d5715043486d4f0f12b882793813f70c26133f22fb9c40d3b4cca_prof);

        
        $__internal_50d1a457991143a00cf242dedf0acb00a673cc96a92812ae002f5df3649b9fba->leave($__internal_50d1a457991143a00cf242dedf0acb00a673cc96a92812ae002f5df3649b9fba_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_8b59133b617886f19b147385a571c24ca678b7cf01ea4fc674c923907c804bde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b59133b617886f19b147385a571c24ca678b7cf01ea4fc674c923907c804bde->enter($__internal_8b59133b617886f19b147385a571c24ca678b7cf01ea4fc674c923907c804bde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9e15b6f5909de43ca87bddc90d0bc1cd7ab56dd995466a8f001427ba976a073e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e15b6f5909de43ca87bddc90d0bc1cd7ab56dd995466a8f001427ba976a073e->enter($__internal_9e15b6f5909de43ca87bddc90d0bc1cd7ab56dd995466a8f001427ba976a073e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Start";
        
        $__internal_9e15b6f5909de43ca87bddc90d0bc1cd7ab56dd995466a8f001427ba976a073e->leave($__internal_9e15b6f5909de43ca87bddc90d0bc1cd7ab56dd995466a8f001427ba976a073e_prof);

        
        $__internal_8b59133b617886f19b147385a571c24ca678b7cf01ea4fc674c923907c804bde->leave($__internal_8b59133b617886f19b147385a571c24ca678b7cf01ea4fc674c923907c804bde_prof);

    }

    // line 39
    public function block_body($context, array $blocks = array())
    {
        $__internal_28606ce2160567bb4783f16d44714052dac5c63004d724dec87915599d9ba869 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28606ce2160567bb4783f16d44714052dac5c63004d724dec87915599d9ba869->enter($__internal_28606ce2160567bb4783f16d44714052dac5c63004d724dec87915599d9ba869_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cc0f2e517779c9b3e793eefd319a899556c9bcab84d710175c13d8168d3d0cba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc0f2e517779c9b3e793eefd319a899556c9bcab84d710175c13d8168d3d0cba->enter($__internal_cc0f2e517779c9b3e793eefd319a899556c9bcab84d710175c13d8168d3d0cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_cc0f2e517779c9b3e793eefd319a899556c9bcab84d710175c13d8168d3d0cba->leave($__internal_cc0f2e517779c9b3e793eefd319a899556c9bcab84d710175c13d8168d3d0cba_prof);

        
        $__internal_28606ce2160567bb4783f16d44714052dac5c63004d724dec87915599d9ba869->leave($__internal_28606ce2160567bb4783f16d44714052dac5c63004d724dec87915599d9ba869_prof);

    }

    // line 44
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_99078385542aec7c852f6fe57294ff2034790c7d6ff26a56bce86803fc41c93d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99078385542aec7c852f6fe57294ff2034790c7d6ff26a56bce86803fc41c93d->enter($__internal_99078385542aec7c852f6fe57294ff2034790c7d6ff26a56bce86803fc41c93d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7d1f31f4776690566491332b2c05198f78c203e731a558049759f54781c9bb3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d1f31f4776690566491332b2c05198f78c203e731a558049759f54781c9bb3f->enter($__internal_7d1f31f4776690566491332b2c05198f78c203e731a558049759f54781c9bb3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 45
        echo "<script>console.log(1234567890);
    var kot = \"kot\";
    var i;
    console.log(kot);
    if(kot == \"pi3s\")
        for(i = 0; i < 11; i++)
            console.log(i);
    else
        for(i = 0; i<10;i++)
            console.log(\"ni3 pi3s\" + i);


    i = -3;
    while (i < 4) {
        console.log(i);
        i++;

    }

    var object = {
        name: \"Maci3k\",
        height: 187,
        print : function() {
            console.log(this.name + \" \" + this.height + \" cm wzrostu\")
        }
    }
    object.print()
</script>
";
        
        $__internal_7d1f31f4776690566491332b2c05198f78c203e731a558049759f54781c9bb3f->leave($__internal_7d1f31f4776690566491332b2c05198f78c203e731a558049759f54781c9bb3f_prof);

        
        $__internal_99078385542aec7c852f6fe57294ff2034790c7d6ff26a56bce86803fc41c93d->leave($__internal_99078385542aec7c852f6fe57294ff2034790c7d6ff26a56bce86803fc41c93d_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 45,  153 => 44,  136 => 39,  118 => 12,  107 => 9,  98 => 8,  86 => 74,  84 => 44,  78 => 40,  76 => 39,  46 => 12,  43 => 11,  41 => 8,  37 => 7,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"description\" content=\"Testing site\">
    <meta name=\"author\" content=\"Mikołaj\">
    <link href=\"{{ asset('bundles/menu_style.css') }}\" type=\"text/css\" rel=\"stylesheet\" />
    {% block stylesheets %}

    {% endblock %}

    <title>{% block title %}Start{% endblock %}</title>

</head>

<body>
<h1 id=\"Main_text\">Hotel</h1>

<nav>
        <ul class=\"ul_menu\">
            <li class=\"li_menu\">
                <a href=\"/\">Domowa</a>
                <a href=\"/my\">Aktualnosci</a>
                <a href=\"/second\">Kontakt</a>
            </li>

            <li class=\"login\">
                <input class=\"login\" type=\"text\" placeholder=\"login\" aria-label=\"log\">
                <input class=\"login\" type=\"password\" placeholder=\"password\" aria-label=\"pass\">
                <button class=\"search_button\" type=\"submit\">Login</button>
            </li>
        </ul>
</nav>

<div class=\"container\">

    <div class=\"row\">
        <div class=\"call-md-12\">
            {% block body %}{% endblock %}
        </div>
    </div>

</div><!-- /.container -->
{% block javascripts %}
<script>console.log(1234567890);
    var kot = \"kot\";
    var i;
    console.log(kot);
    if(kot == \"pi3s\")
        for(i = 0; i < 11; i++)
            console.log(i);
    else
        for(i = 0; i<10;i++)
            console.log(\"ni3 pi3s\" + i);


    i = -3;
    while (i < 4) {
        console.log(i);
        i++;

    }

    var object = {
        name: \"Maci3k\",
        height: 187,
        print : function() {
            console.log(this.name + \" \" + this.height + \" cm wzrostu\")
        }
    }
    object.print()
</script>
{% endblock %}
</body>
</html>
", "base.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/app/Resources/views/base.html.twig");
    }
}
