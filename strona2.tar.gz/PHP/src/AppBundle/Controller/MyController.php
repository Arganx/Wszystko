<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\users1;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;

class MyController extends Controller
{
    /**
     * @Route("/my", name="my_list")
     */
    public function listAction(Request $request)
    {
        return $this->render('my/my.html.twig');
    }

    /**
     * @Route("/second", name="my_second")
     */
    public function secondAction(Request $request)
    {

        $user = $this->getDoctrine()
            ->getRepository('AppBundle:users1')
            ->findAll();
        return $this->render('my/second.html.twig',array('theUser'=>$user));
    }
    /**
     * @Route("/login", name="login")
     */
    public function loginAction(Request $request)
    {
        return $this->render('my/login.html.twig');
    }

    /**
     * @Route("/register", name="register")
     */
    public function registerAction(Request $request)
    {
        $user = new users1();

        $form = $this->createFormBuilder($user)
            ->add('login',TextType::class)
            ->add('password',PasswordType::class)
            ->add('email',EmailType::class)
            ->add('save',SubmitType::class,array('label'=>'Register'))
            ->getForm();

            $form->handleRequest($request);

            if ($form->isSubmitted() && $form->isValid()) {

            $login = $form['login']->getData();
            $password = $form['password']->getData();
            $email = $form['email']->getData();

            $user->setLogin($login);
            $user->setPassword($password);
            $user->setType('normal');
            $user->setEmail($email);

            $em=$this->getDoctrine()->getManager();
            $em->persist($user);
            $em->flush();



            return $this->redirect('/');
            }

        return $this->render('my/register.html.twig',array('form'=> $form->createView()));
    }

}
