<?php

/* my/login.html.twig */
class __TwigTemplate_c679118e0644e322cea6c0a2536457bc312712bc6eb372eef3289b16f29312b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "my/login.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_425820397332e3a1026f613befb0bb83867fe04275678a2dd989d5b0506640b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_425820397332e3a1026f613befb0bb83867fe04275678a2dd989d5b0506640b1->enter($__internal_425820397332e3a1026f613befb0bb83867fe04275678a2dd989d5b0506640b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/login.html.twig"));

        $__internal_5adc7da3010bd20613fc96a59d6353815588d557955c2b551e0f17563186dbb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5adc7da3010bd20613fc96a59d6353815588d557955c2b551e0f17563186dbb8->enter($__internal_5adc7da3010bd20613fc96a59d6353815588d557955c2b551e0f17563186dbb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_425820397332e3a1026f613befb0bb83867fe04275678a2dd989d5b0506640b1->leave($__internal_425820397332e3a1026f613befb0bb83867fe04275678a2dd989d5b0506640b1_prof);

        
        $__internal_5adc7da3010bd20613fc96a59d6353815588d557955c2b551e0f17563186dbb8->leave($__internal_5adc7da3010bd20613fc96a59d6353815588d557955c2b551e0f17563186dbb8_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f69dcbbd28b66d19e954c676a6b573bf8da3e4197bf492cbe7002a0238a3cc52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f69dcbbd28b66d19e954c676a6b573bf8da3e4197bf492cbe7002a0238a3cc52->enter($__internal_f69dcbbd28b66d19e954c676a6b573bf8da3e4197bf492cbe7002a0238a3cc52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8e0abad5bdc6b8d76ebd32f8ad09fdbb953bd7421b1311079afdfd9c9f7d399a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e0abad5bdc6b8d76ebd32f8ad09fdbb953bd7421b1311079afdfd9c9f7d399a->enter($__internal_8e0abad5bdc6b8d76ebd32f8ad09fdbb953bd7421b1311079afdfd9c9f7d399a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/login_style.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
";
        
        $__internal_8e0abad5bdc6b8d76ebd32f8ad09fdbb953bd7421b1311079afdfd9c9f7d399a->leave($__internal_8e0abad5bdc6b8d76ebd32f8ad09fdbb953bd7421b1311079afdfd9c9f7d399a_prof);

        
        $__internal_f69dcbbd28b66d19e954c676a6b573bf8da3e4197bf492cbe7002a0238a3cc52->leave($__internal_f69dcbbd28b66d19e954c676a6b573bf8da3e4197bf492cbe7002a0238a3cc52_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_e7521ec1dde0e2efccbdf2f897aa88f7d77a7e902db9536c075dab65f161aa82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7521ec1dde0e2efccbdf2f897aa88f7d77a7e902db9536c075dab65f161aa82->enter($__internal_e7521ec1dde0e2efccbdf2f897aa88f7d77a7e902db9536c075dab65f161aa82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fa5fac8e2a9aae38349b543eeba3d9dd77fd17c674c8780d5d631fd92fb9c9be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa5fac8e2a9aae38349b543eeba3d9dd77fd17c674c8780d5d631fd92fb9c9be->enter($__internal_fa5fac8e2a9aae38349b543eeba3d9dd77fd17c674c8780d5d631fd92fb9c9be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div id=\"login_box\">
            <li class=\"login_li\"><input class=\"login\" type=\"text\" placeholder=\"login\" aria-label=\"log\"></li>
            <li class=\"login_li\"><input class=\"login\" type=\"password\" placeholder=\"password\" aria-label=\"pass\"></li>
            <li class=\"login_li\"><button class=\"search_button\" type=\"submit\">Login</button></li>
            <li class=\"login_li\"><a href=\"/register\">Nie masz jeszcze konta? Utwórz je teraz</a></li>
    </div>
";
        
        $__internal_fa5fac8e2a9aae38349b543eeba3d9dd77fd17c674c8780d5d631fd92fb9c9be->leave($__internal_fa5fac8e2a9aae38349b543eeba3d9dd77fd17c674c8780d5d631fd92fb9c9be_prof);

        
        $__internal_e7521ec1dde0e2efccbdf2f897aa88f7d77a7e902db9536c075dab65f161aa82->leave($__internal_e7521ec1dde0e2efccbdf2f897aa88f7d77a7e902db9536c075dab65f161aa82_prof);

    }

    // line 18
    public function block_title($context, array $blocks = array())
    {
        $__internal_dd4b4e19c6dc8fdc462ae6ffaff4efd0f144ff2427d3d8fff03243f5556d8780 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd4b4e19c6dc8fdc462ae6ffaff4efd0f144ff2427d3d8fff03243f5556d8780->enter($__internal_dd4b4e19c6dc8fdc462ae6ffaff4efd0f144ff2427d3d8fff03243f5556d8780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_1a493d037bdb3929980d61579f5b4f364fe020dc40c7058c2ab32ffddc5dcd7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a493d037bdb3929980d61579f5b4f364fe020dc40c7058c2ab32ffddc5dcd7d->enter($__internal_1a493d037bdb3929980d61579f5b4f364fe020dc40c7058c2ab32ffddc5dcd7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 19
        echo "    Zaloguj się
";
        
        $__internal_1a493d037bdb3929980d61579f5b4f364fe020dc40c7058c2ab32ffddc5dcd7d->leave($__internal_1a493d037bdb3929980d61579f5b4f364fe020dc40c7058c2ab32ffddc5dcd7d_prof);

        
        $__internal_dd4b4e19c6dc8fdc462ae6ffaff4efd0f144ff2427d3d8fff03243f5556d8780->leave($__internal_dd4b4e19c6dc8fdc462ae6ffaff4efd0f144ff2427d3d8fff03243f5556d8780_prof);

    }

    public function getTemplateName()
    {
        return "my/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 19,  89 => 18,  73 => 9,  64 => 8,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
<link href=\"{{ asset('bundles/login_style.css') }}\" type=\"text/css\" rel=\"stylesheet\" />
{% endblock %}


{% block body %}
    <div id=\"login_box\">
            <li class=\"login_li\"><input class=\"login\" type=\"text\" placeholder=\"login\" aria-label=\"log\"></li>
            <li class=\"login_li\"><input class=\"login\" type=\"password\" placeholder=\"password\" aria-label=\"pass\"></li>
            <li class=\"login_li\"><button class=\"search_button\" type=\"submit\">Login</button></li>
            <li class=\"login_li\"><a href=\"/register\">Nie masz jeszcze konta? Utwórz je teraz</a></li>
    </div>
{% endblock %}


{% block title %}
    Zaloguj się
{% endblock %}", "my/login.html.twig", "/home/arg/Documents/symfony/PHP/app/Resources/views/my/login.html.twig");
    }
}
