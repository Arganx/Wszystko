<?php

/* my/register.html.twig */
class __TwigTemplate_595efffd4557b88f71d019c166f15d9fc8a2897e151a6d56632c35a70a20fe35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "my/register.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6abb03529aa1b0514e65d40934b00d6cd95b8c82873fe9509bc31c9c04d73635 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6abb03529aa1b0514e65d40934b00d6cd95b8c82873fe9509bc31c9c04d73635->enter($__internal_6abb03529aa1b0514e65d40934b00d6cd95b8c82873fe9509bc31c9c04d73635_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/register.html.twig"));

        $__internal_366e1a178fadd28bd009b4a0fb15ce8f139f786773b6aaef1b7da42000589d3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_366e1a178fadd28bd009b4a0fb15ce8f139f786773b6aaef1b7da42000589d3d->enter($__internal_366e1a178fadd28bd009b4a0fb15ce8f139f786773b6aaef1b7da42000589d3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6abb03529aa1b0514e65d40934b00d6cd95b8c82873fe9509bc31c9c04d73635->leave($__internal_6abb03529aa1b0514e65d40934b00d6cd95b8c82873fe9509bc31c9c04d73635_prof);

        
        $__internal_366e1a178fadd28bd009b4a0fb15ce8f139f786773b6aaef1b7da42000589d3d->leave($__internal_366e1a178fadd28bd009b4a0fb15ce8f139f786773b6aaef1b7da42000589d3d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_200bd31e2201c78a849993a80f876e5687ba4aa62fdb63edc1bc168df6ec497f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_200bd31e2201c78a849993a80f876e5687ba4aa62fdb63edc1bc168df6ec497f->enter($__internal_200bd31e2201c78a849993a80f876e5687ba4aa62fdb63edc1bc168df6ec497f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d62e7c0ad046e618b78ae1a2d29ffeb8399425fe64a561d74b3577269b7ad7a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d62e7c0ad046e618b78ae1a2d29ffeb8399425fe64a561d74b3577269b7ad7a1->enter($__internal_d62e7c0ad046e618b78ae1a2d29ffeb8399425fe64a561d74b3577269b7ad7a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Rejestracja
";
        
        $__internal_d62e7c0ad046e618b78ae1a2d29ffeb8399425fe64a561d74b3577269b7ad7a1->leave($__internal_d62e7c0ad046e618b78ae1a2d29ffeb8399425fe64a561d74b3577269b7ad7a1_prof);

        
        $__internal_200bd31e2201c78a849993a80f876e5687ba4aa62fdb63edc1bc168df6ec497f->leave($__internal_200bd31e2201c78a849993a80f876e5687ba4aa62fdb63edc1bc168df6ec497f_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_146997279620e2ca3268526f73bacbdeee6abfe4acafb09ab72d1621ca62e5c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_146997279620e2ca3268526f73bacbdeee6abfe4acafb09ab72d1621ca62e5c1->enter($__internal_146997279620e2ca3268526f73bacbdeee6abfe4acafb09ab72d1621ca62e5c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_78cb19c37190dad9ffc975ab46d5b01b240990d25e9ba1c3e2a7988371667623 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78cb19c37190dad9ffc975ab46d5b01b240990d25e9ba1c3e2a7988371667623->enter($__internal_78cb19c37190dad9ffc975ab46d5b01b240990d25e9ba1c3e2a7988371667623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "    ";
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_78cb19c37190dad9ffc975ab46d5b01b240990d25e9ba1c3e2a7988371667623->leave($__internal_78cb19c37190dad9ffc975ab46d5b01b240990d25e9ba1c3e2a7988371667623_prof);

        
        $__internal_146997279620e2ca3268526f73bacbdeee6abfe4acafb09ab72d1621ca62e5c1->leave($__internal_146997279620e2ca3268526f73bacbdeee6abfe4acafb09ab72d1621ca62e5c1_prof);

    }

    public function getTemplateName()
    {
        return "my/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 10,  75 => 9,  70 => 8,  61 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    Rejestracja
{% endblock %}

{% block body %}
    {{ form_start(form) }}
    {{ form_widget(form) }}
    {{ form_end(form) }}
{% endblock %}", "my/register.html.twig", "/home/arg/Documents/symfony/PHP/app/Resources/views/my/register.html.twig");
    }
}
