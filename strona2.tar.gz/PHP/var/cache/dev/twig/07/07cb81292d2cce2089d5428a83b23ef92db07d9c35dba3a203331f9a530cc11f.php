<?php

/* my/second.html.twig */
class __TwigTemplate_500e937d8b9bbdeecfed29bafd31be1e1b9bb09508bc42677e7721877001f169 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "my/second.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c907b7e42a809fb6d3c49dbfc2f9f84b1290d91c7f46713c7a468180efe18ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c907b7e42a809fb6d3c49dbfc2f9f84b1290d91c7f46713c7a468180efe18ed->enter($__internal_7c907b7e42a809fb6d3c49dbfc2f9f84b1290d91c7f46713c7a468180efe18ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/second.html.twig"));

        $__internal_32950d4225b033389f89cce458a1fc044ec5a6aa0d69e5b80886b7c0ebd2d991 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32950d4225b033389f89cce458a1fc044ec5a6aa0d69e5b80886b7c0ebd2d991->enter($__internal_32950d4225b033389f89cce458a1fc044ec5a6aa0d69e5b80886b7c0ebd2d991_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/second.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c907b7e42a809fb6d3c49dbfc2f9f84b1290d91c7f46713c7a468180efe18ed->leave($__internal_7c907b7e42a809fb6d3c49dbfc2f9f84b1290d91c7f46713c7a468180efe18ed_prof);

        
        $__internal_32950d4225b033389f89cce458a1fc044ec5a6aa0d69e5b80886b7c0ebd2d991->leave($__internal_32950d4225b033389f89cce458a1fc044ec5a6aa0d69e5b80886b7c0ebd2d991_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0218dc08ddd48b3e47999f71166067bdf35076f7d74809eb708907dcba86e798 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0218dc08ddd48b3e47999f71166067bdf35076f7d74809eb708907dcba86e798->enter($__internal_0218dc08ddd48b3e47999f71166067bdf35076f7d74809eb708907dcba86e798_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_611303c17d563bf2cca77ad5824f7a3f70de0caf8baa99df4488981bf5120910 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_611303c17d563bf2cca77ad5824f7a3f70de0caf8baa99df4488981bf5120910->enter($__internal_611303c17d563bf2cca77ad5824f7a3f70de0caf8baa99df4488981bf5120910_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Second
";
        
        $__internal_611303c17d563bf2cca77ad5824f7a3f70de0caf8baa99df4488981bf5120910->leave($__internal_611303c17d563bf2cca77ad5824f7a3f70de0caf8baa99df4488981bf5120910_prof);

        
        $__internal_0218dc08ddd48b3e47999f71166067bdf35076f7d74809eb708907dcba86e798->leave($__internal_0218dc08ddd48b3e47999f71166067bdf35076f7d74809eb708907dcba86e798_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_ac76f2544a1bb9a5e25ad421ac8e1d2dc64c35bffbd28e6907468f54def3a56d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ac76f2544a1bb9a5e25ad421ac8e1d2dc64c35bffbd28e6907468f54def3a56d->enter($__internal_ac76f2544a1bb9a5e25ad421ac8e1d2dc64c35bffbd28e6907468f54def3a56d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c88508697e51461c039434b92428818954f81d5b8c1b342d2bc832c3a3687669 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c88508697e51461c039434b92428818954f81d5b8c1b342d2bc832c3a3687669->enter($__internal_c88508697e51461c039434b92428818954f81d5b8c1b342d2bc832c3a3687669_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["theUser"] ?? $this->getContext($context, "theUser")));
        foreach ($context['_seq'] as $context["_key"] => $context["key"]) {
            // line 10
            echo "        <div>
            ";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "id", array()), "html", null, true);
            echo "
            ";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "login", array()), "html", null, true);
            echo "
            ";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "password", array()), "html", null, true);
            echo "
            ";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "email", array()), "html", null, true);
            echo "

        </div>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['key'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    <div>
        <button>Kliknij mnie</button>
    </div>
";
        
        $__internal_c88508697e51461c039434b92428818954f81d5b8c1b342d2bc832c3a3687669->leave($__internal_c88508697e51461c039434b92428818954f81d5b8c1b342d2bc832c3a3687669_prof);

        
        $__internal_ac76f2544a1bb9a5e25ad421ac8e1d2dc64c35bffbd28e6907468f54def3a56d->leave($__internal_ac76f2544a1bb9a5e25ad421ac8e1d2dc64c35bffbd28e6907468f54def3a56d_prof);

    }

    public function getTemplateName()
    {
        return "my/second.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 19,  90 => 14,  86 => 13,  82 => 12,  78 => 11,  75 => 10,  70 => 9,  61 => 8,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    Second
{% endblock %}


{% block body %}
    {%  for key in theUser %}
        <div>
            {{  key.id }}
            {{  key.login }}
            {{  key.password }}
            {{  key.email }}

        </div>

    {% endfor %}
    <div>
        <button>Kliknij mnie</button>
    </div>
{% endblock %}", "my/second.html.twig", "/home/arg/Documents/symfony/PHP/app/Resources/views/my/second.html.twig");
    }
}
