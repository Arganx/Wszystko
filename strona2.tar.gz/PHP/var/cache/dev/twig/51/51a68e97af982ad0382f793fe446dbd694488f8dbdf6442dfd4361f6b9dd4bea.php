<?php

/* my/my.html.twig */
class __TwigTemplate_d3ebc03bd94724102b50e94336f071b0901f630de0ac1bef48a1774e46972b5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "my/my.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6bc434adef63251bdaa5505c8237af690cf4630ed37247fa5f3c22f34160f83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6bc434adef63251bdaa5505c8237af690cf4630ed37247fa5f3c22f34160f83->enter($__internal_f6bc434adef63251bdaa5505c8237af690cf4630ed37247fa5f3c22f34160f83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/my.html.twig"));

        $__internal_1b9afded503187fa6682c4a8fe520d0c5ee2e6af439092d7db4b65295bd22bce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b9afded503187fa6682c4a8fe520d0c5ee2e6af439092d7db4b65295bd22bce->enter($__internal_1b9afded503187fa6682c4a8fe520d0c5ee2e6af439092d7db4b65295bd22bce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/my.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f6bc434adef63251bdaa5505c8237af690cf4630ed37247fa5f3c22f34160f83->leave($__internal_f6bc434adef63251bdaa5505c8237af690cf4630ed37247fa5f3c22f34160f83_prof);

        
        $__internal_1b9afded503187fa6682c4a8fe520d0c5ee2e6af439092d7db4b65295bd22bce->leave($__internal_1b9afded503187fa6682c4a8fe520d0c5ee2e6af439092d7db4b65295bd22bce_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0388556b65443b5b27b356892acd0801add72b28a918edc9d49c26424647677e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0388556b65443b5b27b356892acd0801add72b28a918edc9d49c26424647677e->enter($__internal_0388556b65443b5b27b356892acd0801add72b28a918edc9d49c26424647677e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_56e019e672b237c536c0d5af5dcfe98731e38e59b2fd7b14ccf4d42a783e0d48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56e019e672b237c536c0d5af5dcfe98731e38e59b2fd7b14ccf4d42a783e0d48->enter($__internal_56e019e672b237c536c0d5af5dcfe98731e38e59b2fd7b14ccf4d42a783e0d48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/styl.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
";
        
        $__internal_56e019e672b237c536c0d5af5dcfe98731e38e59b2fd7b14ccf4d42a783e0d48->leave($__internal_56e019e672b237c536c0d5af5dcfe98731e38e59b2fd7b14ccf4d42a783e0d48_prof);

        
        $__internal_0388556b65443b5b27b356892acd0801add72b28a918edc9d49c26424647677e->leave($__internal_0388556b65443b5b27b356892acd0801add72b28a918edc9d49c26424647677e_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_ff07dea8c1a836aac77d9df76fb3532cf9abc0893820ec1a4f68d3aba88db69e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff07dea8c1a836aac77d9df76fb3532cf9abc0893820ec1a4f68d3aba88db69e->enter($__internal_ff07dea8c1a836aac77d9df76fb3532cf9abc0893820ec1a4f68d3aba88db69e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_47c9f58a196c865ec714098e8d0041507768b481aa81e4a90afebad0c6d8e2da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47c9f58a196c865ec714098e8d0041507768b481aa81e4a90afebad0c6d8e2da->enter($__internal_47c9f58a196c865ec714098e8d0041507768b481aa81e4a90afebad0c6d8e2da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    Tytul
";
        
        $__internal_47c9f58a196c865ec714098e8d0041507768b481aa81e4a90afebad0c6d8e2da->leave($__internal_47c9f58a196c865ec714098e8d0041507768b481aa81e4a90afebad0c6d8e2da_prof);

        
        $__internal_ff07dea8c1a836aac77d9df76fb3532cf9abc0893820ec1a4f68d3aba88db69e->leave($__internal_ff07dea8c1a836aac77d9df76fb3532cf9abc0893820ec1a4f68d3aba88db69e_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_3407a3a55b3de362768a206f560db92c9ba81c0dc77a7710a8a8e627c9ce450c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3407a3a55b3de362768a206f560db92c9ba81c0dc77a7710a8a8e627c9ce450c->enter($__internal_3407a3a55b3de362768a206f560db92c9ba81c0dc77a7710a8a8e627c9ce450c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f741972c164af3da2add70e904d55833d9ca39a0f6152935ee7d4b6d5041e73a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f741972c164af3da2add70e904d55833d9ca39a0f6152935ee7d4b6d5041e73a->enter($__internal_f741972c164af3da2add70e904d55833d9ca39a0f6152935ee7d4b6d5041e73a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "    <h1>Starting my page</h1>
";
        
        $__internal_f741972c164af3da2add70e904d55833d9ca39a0f6152935ee7d4b6d5041e73a->leave($__internal_f741972c164af3da2add70e904d55833d9ca39a0f6152935ee7d4b6d5041e73a_prof);

        
        $__internal_3407a3a55b3de362768a206f560db92c9ba81c0dc77a7710a8a8e627c9ce450c->leave($__internal_3407a3a55b3de362768a206f560db92c9ba81c0dc77a7710a8a8e627c9ce450c_prof);

    }

    public function getTemplateName()
    {
        return "my/my.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 14,  84 => 13,  73 => 9,  64 => 8,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
    <link href=\"{{ asset('bundles/styl.css') }}\" type=\"text/css\" rel=\"stylesheet\" />
{% endblock %}


{% block title %}
    Tytul
{% endblock %}


{% block body %}
    <h1>Starting my page</h1>
{% endblock %}", "my/my.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/app/Resources/views/my/my.html.twig");
    }
}
