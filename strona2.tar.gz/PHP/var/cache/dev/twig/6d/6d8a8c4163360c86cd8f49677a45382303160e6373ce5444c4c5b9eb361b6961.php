<?php

/* base.html.twig */
class __TwigTemplate_ef6a598e82a5011af52d5b328f0cd2f8830bea5f4c88506ad9e23671aec9697a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24e76a4d70839b011a4a2582ccad15ba3282c067f44730d06967c1dc558d22d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24e76a4d70839b011a4a2582ccad15ba3282c067f44730d06967c1dc558d22d4->enter($__internal_24e76a4d70839b011a4a2582ccad15ba3282c067f44730d06967c1dc558d22d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_536bed2a507c1be8409f2d433d88959e216f42f7e91fb7d3f40e7731149300af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_536bed2a507c1be8409f2d433d88959e216f42f7e91fb7d3f40e7731149300af->enter($__internal_536bed2a507c1be8409f2d433d88959e216f42f7e91fb7d3f40e7731149300af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"description\" content=\"Testing site\">
    <meta name=\"author\" content=\"Mikołaj\">
    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/menu_style.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
    ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "
    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

</head>

<body>
<h1 id=\"Main_text\">Hotel</h1>

<nav>
        <ul class=\"ul_menu\">
            <li class=\"li_menu\">
                <a class =\"Menu_text\" href=\"/\">Domowa</a>
                <a class =\"Menu_text\" href=\"/my\">Aktualnosci</a>
                <a class =\"Menu_text\" href=\"/second\">Kontakt</a>
            </li>

            <li class=\"to_login\">
                <a id=\"menu_login\" href=\"/login\">Zaloguj sie</a>
            </li>
        </ul>
</nav>

<div class=\"container\">

    <div class=\"row\">
        <div class=\"call-md-12\">
            ";
        // line 37
        $this->displayBlock('body', $context, $blocks);
        // line 38
        echo "        </div>
    </div>

</div><!-- /.container -->
";
        // line 42
        $this->displayBlock('javascripts', $context, $blocks);
        // line 72
        echo "</body>
</html>
";
        
        $__internal_24e76a4d70839b011a4a2582ccad15ba3282c067f44730d06967c1dc558d22d4->leave($__internal_24e76a4d70839b011a4a2582ccad15ba3282c067f44730d06967c1dc558d22d4_prof);

        
        $__internal_536bed2a507c1be8409f2d433d88959e216f42f7e91fb7d3f40e7731149300af->leave($__internal_536bed2a507c1be8409f2d433d88959e216f42f7e91fb7d3f40e7731149300af_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_02faeacf7be16c433e9d7ef9a0d8ab363f2e55192080a9c4bbc56894cd3b6fbf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02faeacf7be16c433e9d7ef9a0d8ab363f2e55192080a9c4bbc56894cd3b6fbf->enter($__internal_02faeacf7be16c433e9d7ef9a0d8ab363f2e55192080a9c4bbc56894cd3b6fbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b3b705fef0b43c5909c2dbde75bf3b515b20091649151ff77e9bc6221f2d9f43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3b705fef0b43c5909c2dbde75bf3b515b20091649151ff77e9bc6221f2d9f43->enter($__internal_b3b705fef0b43c5909c2dbde75bf3b515b20091649151ff77e9bc6221f2d9f43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "
    ";
        
        $__internal_b3b705fef0b43c5909c2dbde75bf3b515b20091649151ff77e9bc6221f2d9f43->leave($__internal_b3b705fef0b43c5909c2dbde75bf3b515b20091649151ff77e9bc6221f2d9f43_prof);

        
        $__internal_02faeacf7be16c433e9d7ef9a0d8ab363f2e55192080a9c4bbc56894cd3b6fbf->leave($__internal_02faeacf7be16c433e9d7ef9a0d8ab363f2e55192080a9c4bbc56894cd3b6fbf_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_cdf377213685f6faac2b6021d35cb3a2f91f40574e72a2a62d1e5de70e104e7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cdf377213685f6faac2b6021d35cb3a2f91f40574e72a2a62d1e5de70e104e7a->enter($__internal_cdf377213685f6faac2b6021d35cb3a2f91f40574e72a2a62d1e5de70e104e7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5eab144eec6b71b03d9cf534ac842e05deaebc84e60d926bfcab11112b69e540 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5eab144eec6b71b03d9cf534ac842e05deaebc84e60d926bfcab11112b69e540->enter($__internal_5eab144eec6b71b03d9cf534ac842e05deaebc84e60d926bfcab11112b69e540_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Start";
        
        $__internal_5eab144eec6b71b03d9cf534ac842e05deaebc84e60d926bfcab11112b69e540->leave($__internal_5eab144eec6b71b03d9cf534ac842e05deaebc84e60d926bfcab11112b69e540_prof);

        
        $__internal_cdf377213685f6faac2b6021d35cb3a2f91f40574e72a2a62d1e5de70e104e7a->leave($__internal_cdf377213685f6faac2b6021d35cb3a2f91f40574e72a2a62d1e5de70e104e7a_prof);

    }

    // line 37
    public function block_body($context, array $blocks = array())
    {
        $__internal_a92c096643ecf0f3474eaa5164ed352bd341c65834a0a91de46e95ddb25aefe5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a92c096643ecf0f3474eaa5164ed352bd341c65834a0a91de46e95ddb25aefe5->enter($__internal_a92c096643ecf0f3474eaa5164ed352bd341c65834a0a91de46e95ddb25aefe5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4f15d4bb2b25e1a483a6d0bf3ac2f3fb0a4ae5d8f64632dadb283783c9d660de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f15d4bb2b25e1a483a6d0bf3ac2f3fb0a4ae5d8f64632dadb283783c9d660de->enter($__internal_4f15d4bb2b25e1a483a6d0bf3ac2f3fb0a4ae5d8f64632dadb283783c9d660de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_4f15d4bb2b25e1a483a6d0bf3ac2f3fb0a4ae5d8f64632dadb283783c9d660de->leave($__internal_4f15d4bb2b25e1a483a6d0bf3ac2f3fb0a4ae5d8f64632dadb283783c9d660de_prof);

        
        $__internal_a92c096643ecf0f3474eaa5164ed352bd341c65834a0a91de46e95ddb25aefe5->leave($__internal_a92c096643ecf0f3474eaa5164ed352bd341c65834a0a91de46e95ddb25aefe5_prof);

    }

    // line 42
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_70e1afdac0f05456d2cbf10a38e5136a527b9c3642be59fb6dfef1a5cb5b6e00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70e1afdac0f05456d2cbf10a38e5136a527b9c3642be59fb6dfef1a5cb5b6e00->enter($__internal_70e1afdac0f05456d2cbf10a38e5136a527b9c3642be59fb6dfef1a5cb5b6e00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_92751a2c7d69251ff8c97e39f06e9d0b75d2936007bcd4adf3bc0bffc66f91f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92751a2c7d69251ff8c97e39f06e9d0b75d2936007bcd4adf3bc0bffc66f91f9->enter($__internal_92751a2c7d69251ff8c97e39f06e9d0b75d2936007bcd4adf3bc0bffc66f91f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 43
        echo "<script>console.log(1234567890);
    var kot = \"kot\";
    var i;
    console.log(kot);
    if(kot == \"pi3s\")
        for(i = 0; i < 11; i++)
            console.log(i);
    else
        for(i = 0; i<10;i++)
            console.log(\"ni3 pi3s\" + i);


    i = -3;
    while (i < 4) {
        console.log(i);
        i++;

    }

    var object = {
        name: \"Maci3k\",
        height: 187,
        print : function() {
            console.log(this.name + \" \" + this.height + \" cm wzrostu\")
        }
    }
    object.print()
</script>
";
        
        $__internal_92751a2c7d69251ff8c97e39f06e9d0b75d2936007bcd4adf3bc0bffc66f91f9->leave($__internal_92751a2c7d69251ff8c97e39f06e9d0b75d2936007bcd4adf3bc0bffc66f91f9_prof);

        
        $__internal_70e1afdac0f05456d2cbf10a38e5136a527b9c3642be59fb6dfef1a5cb5b6e00->leave($__internal_70e1afdac0f05456d2cbf10a38e5136a527b9c3642be59fb6dfef1a5cb5b6e00_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 43,  151 => 42,  134 => 37,  116 => 12,  105 => 9,  96 => 8,  84 => 72,  82 => 42,  76 => 38,  74 => 37,  46 => 12,  43 => 11,  41 => 8,  37 => 7,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"description\" content=\"Testing site\">
    <meta name=\"author\" content=\"Mikołaj\">
    <link href=\"{{ asset('bundles/menu_style.css') }}\" type=\"text/css\" rel=\"stylesheet\" />
    {% block stylesheets %}

    {% endblock %}

    <title>{% block title %}Start{% endblock %}</title>

</head>

<body>
<h1 id=\"Main_text\">Hotel</h1>

<nav>
        <ul class=\"ul_menu\">
            <li class=\"li_menu\">
                <a class =\"Menu_text\" href=\"/\">Domowa</a>
                <a class =\"Menu_text\" href=\"/my\">Aktualnosci</a>
                <a class =\"Menu_text\" href=\"/second\">Kontakt</a>
            </li>

            <li class=\"to_login\">
                <a id=\"menu_login\" href=\"/login\">Zaloguj sie</a>
            </li>
        </ul>
</nav>

<div class=\"container\">

    <div class=\"row\">
        <div class=\"call-md-12\">
            {% block body %}{% endblock %}
        </div>
    </div>

</div><!-- /.container -->
{% block javascripts %}
<script>console.log(1234567890);
    var kot = \"kot\";
    var i;
    console.log(kot);
    if(kot == \"pi3s\")
        for(i = 0; i < 11; i++)
            console.log(i);
    else
        for(i = 0; i<10;i++)
            console.log(\"ni3 pi3s\" + i);


    i = -3;
    while (i < 4) {
        console.log(i);
        i++;

    }

    var object = {
        name: \"Maci3k\",
        height: 187,
        print : function() {
            console.log(this.name + \" \" + this.height + \" cm wzrostu\")
        }
    }
    object.print()
</script>
{% endblock %}
</body>
</html>
", "base.html.twig", "/home/arg/Documents/symfony/PHP/app/Resources/views/base.html.twig");
    }
}
