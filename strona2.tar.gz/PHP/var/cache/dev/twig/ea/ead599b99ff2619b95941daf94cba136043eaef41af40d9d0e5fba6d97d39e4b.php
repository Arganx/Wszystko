<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_2818adb03de0349061047d8de12e1cb1f6b314a5fb9b9431c7361d075fded912 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1804677a9af96c1e678419aa9f778da058f7f34e791820bf345073e98cb9aea8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1804677a9af96c1e678419aa9f778da058f7f34e791820bf345073e98cb9aea8->enter($__internal_1804677a9af96c1e678419aa9f778da058f7f34e791820bf345073e98cb9aea8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_4a2ec7b7b146e3889f3e31027253a6098f7c779eada889b07bd1accfab8aa7ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a2ec7b7b146e3889f3e31027253a6098f7c779eada889b07bd1accfab8aa7ed->enter($__internal_4a2ec7b7b146e3889f3e31027253a6098f7c779eada889b07bd1accfab8aa7ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_1804677a9af96c1e678419aa9f778da058f7f34e791820bf345073e98cb9aea8->leave($__internal_1804677a9af96c1e678419aa9f778da058f7f34e791820bf345073e98cb9aea8_prof);

        
        $__internal_4a2ec7b7b146e3889f3e31027253a6098f7c779eada889b07bd1accfab8aa7ed->leave($__internal_4a2ec7b7b146e3889f3e31027253a6098f7c779eada889b07bd1accfab8aa7ed_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
