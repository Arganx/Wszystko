<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_6c775e4c4ccdb3af11f3aa2031a382d5c0ed87f26f326c1f292fdbc62fcd4060 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6eada2503063e07a4cf4366e76cc734058928e41f6985e334df771b15746835 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6eada2503063e07a4cf4366e76cc734058928e41f6985e334df771b15746835->enter($__internal_c6eada2503063e07a4cf4366e76cc734058928e41f6985e334df771b15746835_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_bf99f100771db18d86301b80fb01ffd4d0456709f2a0e1b2d9e8775d88764926 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf99f100771db18d86301b80fb01ffd4d0456709f2a0e1b2d9e8775d88764926->enter($__internal_bf99f100771db18d86301b80fb01ffd4d0456709f2a0e1b2d9e8775d88764926_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c6eada2503063e07a4cf4366e76cc734058928e41f6985e334df771b15746835->leave($__internal_c6eada2503063e07a4cf4366e76cc734058928e41f6985e334df771b15746835_prof);

        
        $__internal_bf99f100771db18d86301b80fb01ffd4d0456709f2a0e1b2d9e8775d88764926->leave($__internal_bf99f100771db18d86301b80fb01ffd4d0456709f2a0e1b2d9e8775d88764926_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e5f5f022e7eb5afedac7e4cf42ced47f4f7b2864b588eee0ecc14c1a6a4ee605 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5f5f022e7eb5afedac7e4cf42ced47f4f7b2864b588eee0ecc14c1a6a4ee605->enter($__internal_e5f5f022e7eb5afedac7e4cf42ced47f4f7b2864b588eee0ecc14c1a6a4ee605_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_725082b2379bf4d021b8e1489a73f8631bef939bb7adac95f35c78cf351be6cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_725082b2379bf4d021b8e1489a73f8631bef939bb7adac95f35c78cf351be6cf->enter($__internal_725082b2379bf4d021b8e1489a73f8631bef939bb7adac95f35c78cf351be6cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_725082b2379bf4d021b8e1489a73f8631bef939bb7adac95f35c78cf351be6cf->leave($__internal_725082b2379bf4d021b8e1489a73f8631bef939bb7adac95f35c78cf351be6cf_prof);

        
        $__internal_e5f5f022e7eb5afedac7e4cf42ced47f4f7b2864b588eee0ecc14c1a6a4ee605->leave($__internal_e5f5f022e7eb5afedac7e4cf42ced47f4f7b2864b588eee0ecc14c1a6a4ee605_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_9f9f8c9aa782d0174c1c8df458819d6d609bc9b8113f355ab10c10640960561d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f9f8c9aa782d0174c1c8df458819d6d609bc9b8113f355ab10c10640960561d->enter($__internal_9f9f8c9aa782d0174c1c8df458819d6d609bc9b8113f355ab10c10640960561d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0ea5f2bcb921c0adecf3463f94961b0914d1b337160fb5a522ef0accd6da3255 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ea5f2bcb921c0adecf3463f94961b0914d1b337160fb5a522ef0accd6da3255->enter($__internal_0ea5f2bcb921c0adecf3463f94961b0914d1b337160fb5a522ef0accd6da3255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0ea5f2bcb921c0adecf3463f94961b0914d1b337160fb5a522ef0accd6da3255->leave($__internal_0ea5f2bcb921c0adecf3463f94961b0914d1b337160fb5a522ef0accd6da3255_prof);

        
        $__internal_9f9f8c9aa782d0174c1c8df458819d6d609bc9b8113f355ab10c10640960561d->leave($__internal_9f9f8c9aa782d0174c1c8df458819d6d609bc9b8113f355ab10c10640960561d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_1508f5bf18fa89a729fca53bb12e3d634c4c525b75e06f97c8c99c540b619180 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1508f5bf18fa89a729fca53bb12e3d634c4c525b75e06f97c8c99c540b619180->enter($__internal_1508f5bf18fa89a729fca53bb12e3d634c4c525b75e06f97c8c99c540b619180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_bd0880253635b6bbb9a941e550630da491cda483cf75534543720c3d0d411bba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd0880253635b6bbb9a941e550630da491cda483cf75534543720c3d0d411bba->enter($__internal_bd0880253635b6bbb9a941e550630da491cda483cf75534543720c3d0d411bba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_bd0880253635b6bbb9a941e550630da491cda483cf75534543720c3d0d411bba->leave($__internal_bd0880253635b6bbb9a941e550630da491cda483cf75534543720c3d0d411bba_prof);

        
        $__internal_1508f5bf18fa89a729fca53bb12e3d634c4c525b75e06f97c8c99c540b619180->leave($__internal_1508f5bf18fa89a729fca53bb12e3d634c4c525b75e06f97c8c99c540b619180_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
