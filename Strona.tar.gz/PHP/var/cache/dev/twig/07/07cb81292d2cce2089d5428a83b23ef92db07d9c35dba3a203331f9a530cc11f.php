<?php

/* my/second.html.twig */
class __TwigTemplate_500e937d8b9bbdeecfed29bafd31be1e1b9bb09508bc42677e7721877001f169 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "my/second.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe19d5b47d5a84db1a612583344ef61da4dbb2f4ee9de10885625d1a55edd2c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe19d5b47d5a84db1a612583344ef61da4dbb2f4ee9de10885625d1a55edd2c2->enter($__internal_fe19d5b47d5a84db1a612583344ef61da4dbb2f4ee9de10885625d1a55edd2c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/second.html.twig"));

        $__internal_2f7056741256ddfd1c0508486c68743957e8b114035389e2050e3e13e4559fdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f7056741256ddfd1c0508486c68743957e8b114035389e2050e3e13e4559fdd->enter($__internal_2f7056741256ddfd1c0508486c68743957e8b114035389e2050e3e13e4559fdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "my/second.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fe19d5b47d5a84db1a612583344ef61da4dbb2f4ee9de10885625d1a55edd2c2->leave($__internal_fe19d5b47d5a84db1a612583344ef61da4dbb2f4ee9de10885625d1a55edd2c2_prof);

        
        $__internal_2f7056741256ddfd1c0508486c68743957e8b114035389e2050e3e13e4559fdd->leave($__internal_2f7056741256ddfd1c0508486c68743957e8b114035389e2050e3e13e4559fdd_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_e48b78eacfbdd5bb22997d16a2cb6b721e55fe269c01cf5d156eba036a972eb2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e48b78eacfbdd5bb22997d16a2cb6b721e55fe269c01cf5d156eba036a972eb2->enter($__internal_e48b78eacfbdd5bb22997d16a2cb6b721e55fe269c01cf5d156eba036a972eb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f538c61916e37c8077c3525ba514f0868d351e9d12cecdd57e8060792d90e5ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f538c61916e37c8077c3525ba514f0868d351e9d12cecdd57e8060792d90e5ce->enter($__internal_f538c61916e37c8077c3525ba514f0868d351e9d12cecdd57e8060792d90e5ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Second
";
        
        $__internal_f538c61916e37c8077c3525ba514f0868d351e9d12cecdd57e8060792d90e5ce->leave($__internal_f538c61916e37c8077c3525ba514f0868d351e9d12cecdd57e8060792d90e5ce_prof);

        
        $__internal_e48b78eacfbdd5bb22997d16a2cb6b721e55fe269c01cf5d156eba036a972eb2->leave($__internal_e48b78eacfbdd5bb22997d16a2cb6b721e55fe269c01cf5d156eba036a972eb2_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_9e6842652d843be2d6c3d17fc3fb459cd10562731e154ac23507e4b4332088d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e6842652d843be2d6c3d17fc3fb459cd10562731e154ac23507e4b4332088d9->enter($__internal_9e6842652d843be2d6c3d17fc3fb459cd10562731e154ac23507e4b4332088d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_33a780e7da4daf3ddc05f68373db1dc7ebc25f9e33becc4ae3fe14dd87512f5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33a780e7da4daf3ddc05f68373db1dc7ebc25f9e33becc4ae3fe14dd87512f5d->enter($__internal_33a780e7da4daf3ddc05f68373db1dc7ebc25f9e33becc4ae3fe14dd87512f5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div>
        <button>Kliknij mnie</button>
    </div>
";
        
        $__internal_33a780e7da4daf3ddc05f68373db1dc7ebc25f9e33becc4ae3fe14dd87512f5d->leave($__internal_33a780e7da4daf3ddc05f68373db1dc7ebc25f9e33becc4ae3fe14dd87512f5d_prof);

        
        $__internal_9e6842652d843be2d6c3d17fc3fb459cd10562731e154ac23507e4b4332088d9->leave($__internal_9e6842652d843be2d6c3d17fc3fb459cd10562731e154ac23507e4b4332088d9_prof);

    }

    public function getTemplateName()
    {
        return "my/second.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 9,  61 => 8,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    Second
{% endblock %}


{% block body %}
    <div>
        <button>Kliknij mnie</button>
    </div>
{% endblock %}", "my/second.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/app/Resources/views/my/second.html.twig");
    }
}
