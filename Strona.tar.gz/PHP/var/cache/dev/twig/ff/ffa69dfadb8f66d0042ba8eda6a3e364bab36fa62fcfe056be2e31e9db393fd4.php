<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_5bb381d2016f4fb31ed76213b789caa25a3f81b0f29e559643b0dd7ce9f134c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba0cc536c8432de2b87dc403a922b75b3e3f21fefb580122fb5ef11d6ebad13a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba0cc536c8432de2b87dc403a922b75b3e3f21fefb580122fb5ef11d6ebad13a->enter($__internal_ba0cc536c8432de2b87dc403a922b75b3e3f21fefb580122fb5ef11d6ebad13a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_3feda8787ab04bc2984250ba3e4b7f3b332b2b7f45dd1ee6bf2aa862d83f2835 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3feda8787ab04bc2984250ba3e4b7f3b332b2b7f45dd1ee6bf2aa862d83f2835->enter($__internal_3feda8787ab04bc2984250ba3e4b7f3b332b2b7f45dd1ee6bf2aa862d83f2835_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_ba0cc536c8432de2b87dc403a922b75b3e3f21fefb580122fb5ef11d6ebad13a->leave($__internal_ba0cc536c8432de2b87dc403a922b75b3e3f21fefb580122fb5ef11d6ebad13a_prof);

        
        $__internal_3feda8787ab04bc2984250ba3e4b7f3b332b2b7f45dd1ee6bf2aa862d83f2835->leave($__internal_3feda8787ab04bc2984250ba3e4b7f3b332b2b7f45dd1ee6bf2aa862d83f2835_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3526ea5eb9d9395f947eb1812efb2e13cb5ec2b80a5221e3ffb700fa897bdbd5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3526ea5eb9d9395f947eb1812efb2e13cb5ec2b80a5221e3ffb700fa897bdbd5->enter($__internal_3526ea5eb9d9395f947eb1812efb2e13cb5ec2b80a5221e3ffb700fa897bdbd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0eb0413fe4218807b61247975b4c6cfe1ca4ca7edaea2a417469a62855da4dac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eb0413fe4218807b61247975b4c6cfe1ca4ca7edaea2a417469a62855da4dac->enter($__internal_0eb0413fe4218807b61247975b4c6cfe1ca4ca7edaea2a417469a62855da4dac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_0eb0413fe4218807b61247975b4c6cfe1ca4ca7edaea2a417469a62855da4dac->leave($__internal_0eb0413fe4218807b61247975b4c6cfe1ca4ca7edaea2a417469a62855da4dac_prof);

        
        $__internal_3526ea5eb9d9395f947eb1812efb2e13cb5ec2b80a5221e3ffb700fa897bdbd5->leave($__internal_3526ea5eb9d9395f947eb1812efb2e13cb5ec2b80a5221e3ffb700fa897bdbd5_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_9bcf407fe3f82718beb6b89b594cd8d5db9560de9af6d937e2a6f87e89e6b2ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9bcf407fe3f82718beb6b89b594cd8d5db9560de9af6d937e2a6f87e89e6b2ed->enter($__internal_9bcf407fe3f82718beb6b89b594cd8d5db9560de9af6d937e2a6f87e89e6b2ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_06ef35dc8d1805f136c4c1e6b9ebb4dc273933dd0fb330c9c4fd54e1d505b603 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06ef35dc8d1805f136c4c1e6b9ebb4dc273933dd0fb330c9c4fd54e1d505b603->enter($__internal_06ef35dc8d1805f136c4c1e6b9ebb4dc273933dd0fb330c9c4fd54e1d505b603_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_06ef35dc8d1805f136c4c1e6b9ebb4dc273933dd0fb330c9c4fd54e1d505b603->leave($__internal_06ef35dc8d1805f136c4c1e6b9ebb4dc273933dd0fb330c9c4fd54e1d505b603_prof);

        
        $__internal_9bcf407fe3f82718beb6b89b594cd8d5db9560de9af6d937e2a6f87e89e6b2ed->leave($__internal_9bcf407fe3f82718beb6b89b594cd8d5db9560de9af6d937e2a6f87e89e6b2ed_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_2b76a556785c9ebf729c0e35e19962d533f81b3dd9d1b9518ca9ee0b59f789f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b76a556785c9ebf729c0e35e19962d533f81b3dd9d1b9518ca9ee0b59f789f3->enter($__internal_2b76a556785c9ebf729c0e35e19962d533f81b3dd9d1b9518ca9ee0b59f789f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bfc51c11a34ddfcdaa2d20095ab50ed5a887ae32a7e3781c2c6d9d1dd5904922 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfc51c11a34ddfcdaa2d20095ab50ed5a887ae32a7e3781c2c6d9d1dd5904922->enter($__internal_bfc51c11a34ddfcdaa2d20095ab50ed5a887ae32a7e3781c2c6d9d1dd5904922_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_bfc51c11a34ddfcdaa2d20095ab50ed5a887ae32a7e3781c2c6d9d1dd5904922->leave($__internal_bfc51c11a34ddfcdaa2d20095ab50ed5a887ae32a7e3781c2c6d9d1dd5904922_prof);

        
        $__internal_2b76a556785c9ebf729c0e35e19962d533f81b3dd9d1b9518ca9ee0b59f789f3->leave($__internal_2b76a556785c9ebf729c0e35e19962d533f81b3dd9d1b9518ca9ee0b59f789f3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "/media/argan/c2107962-7bbe-48a2-93a7-cd9346a62c60/argan/PHP/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/layout.html.twig");
    }
}
